
var banana,bananaimg;
var obsatacle,obstacleimg;
var background;
var score;

function preload() {
  banana = loadImage("banan.png");
  bananaimg = loadImage("banana-1.png");
  background = ("jungle.png");
}

function setup() {
  createCanvas(400, 400);
  
  banana =  createSprite(280,360,10.10);
}

function draw() {
  background(220);
  drawSprites();
}
